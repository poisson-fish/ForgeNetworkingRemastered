﻿using BeardedManStudios.Forge.Networking.Frame;

namespace BeardedManStudios.Forge.Networking.Generated
{
	public partial class NetworkObjectFactory
	{
		private bool ValidateCreateRequest(NetWorker networker, int identity, uint id, FrameStream frame)
		{
			// TODO:  Write custom code to validate client object create requests
			return true;
		}
	}
}